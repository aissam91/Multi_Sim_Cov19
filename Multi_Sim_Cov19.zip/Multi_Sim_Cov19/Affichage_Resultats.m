
% Affichage des resultats
  clf;
  figure(1)
  %maximize(figure(1))
  axis equal;
  axis([Xmin Xmax Ymin Ymax]);
   hold on
% limits=[0,50,0,10];
% hcells=plotGrid( limits );
 imagesc(Xmin:hx:Xmax,Ymin:hx:Ymax,Ca);
 %imagesc(xmin:hx:xmax,ymin:hx:ymax,Cs);
 %title('sigma=0.1732');
 %plot(nbr_s)
 colormap default
 colorbar;
 %caxis([0 1]);
% title({['Number of persons= ', num2str(Nb_objets)];[('T = '),num2str(h*n)]}); % � modifier si n�cessaire
 title({[('T = '),num2str(h*n)],[('Number of person = '),num2str(Nb_objets)]});

  hold on   
  % On dessine les objets
    for k=1:length(p_s)
      Dessiner_Objet(p_s(k));
      %%%Dans le cas d'un scenario d'entree%%%
      %for k=1:size(i_agent,1)
      %Dessiner_Objet_entree(i_agent(k));
% %        if Code(i)==1
% %         plot(cc(2*i-1,:),cc(2*i,:),'g')
% %        elseif Code(i)==2
% %              plot(cc(2*i-1,:),cc(2*i,:),'b')
% %        else
% %              plot(cc(2*i-1,:),cc(2*i,:),'r')
% %        end

    end
    if isempty(p_infectious)==0
    for k=1:length(p_infectious)
        Dessiner_Objet(p_infectious(k));
    end
    end
%     if isempty(p_infecte)==0
%     for k=1:length(p_infecte(:,1))
%         Dessiner_Objet(p_infecte(k));
%     end
%     end
  % On dessine les obstacles
        % Rectangulaires
        hold on
        for i=1:Nb_obstacles_Rectangle
           Dessiner_Obstacle_Rectangle (i);
        end
%          for i=1:Nb_Sortie
%            Dessiner_Sortie(i);
%          end
%         hold on
%         % Circulaires
%         for i=1:Nb_obstacles_Cercle
%            Dessiner_Obstacle_Cercle (i);
%         end  
%    
    