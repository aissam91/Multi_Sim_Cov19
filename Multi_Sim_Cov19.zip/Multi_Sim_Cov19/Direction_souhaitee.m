% Initialisation du vecteur Vitesse souhait�e 

global Nb_objets
global Direcs

% p=ph/10; %pas de la discr�tisation raffin�e du maillage fast Marching. 
% 
% %for i=1:Nb_objets
%     
% 
%    
% %                 nnc=round((q(2*i-1)-Xminn)/p)+1;
% %                 nnl=round((Ymaxx-q(2*i))/p)+1;
% %                  V_S(2*i-1)=FXN(nnl,nnc);
% %                  V_S(2*i)=-FYN(nnl,nnc);
%                
% %end
% 
% nnc=round((q(2*[1:Nb_objets]-1)-Xminn)./p)+1;
% nnl=round((Ymaxx-q(2*[1:Nb_objets]))./p)+1;
% %nnl=round((q(2*[1:Nb_objets])-Yminn)./p)+1;
% posi=(nnc-1)*size(FXN,1)+nnl;
% %posi=sub2ind(size(FXN),nnl,nnc);
% D_S(2*[1:Nb_objets]-1)=FXN(posi);
% D_S(2*[1:Nb_objets])=-FYN(posi);
% % % D_S(2*[1:Nb_objets]-1)=FXN(nnl,nnc);
% % % D_S(2*[1:Nb_objets])=-FYN(nnl,nnc);
% if mod(n,1000)==0 || n==1
%     D_S=zeros(2*Nb_objets,1);
%     choice=randi(8,1,Nb_objets);
%     D_S(2*[1:Nb_objets]-1)=Direcs(choice,1)
%     D_S(2*[1:Nb_objets])=Direcs(choice,2)
% end
if  n==1
    D_S=zeros(2*Nb_objets,1);
    choice=randi(8,1,Nb_objets);
    D_S(2*[1:Nb_objets]-1)=Direcs(choice,1);
    D_S(2*[1:Nb_objets])=Direcs(choice,2);
elseif mod(n,1000)==0
    aa=randi(Nb_objets,1,floor(Nb_objets*0.3));
    choice=randi(8,1,floor(Nb_objets*0.3));
    D_S(2*aa-1)=Direcs(choice,1);
    D_S(2*aa)=Direcs(choice,2);
end
