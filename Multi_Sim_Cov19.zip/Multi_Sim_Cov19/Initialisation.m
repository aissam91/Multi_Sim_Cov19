clear all,
Variables_Globales;
%% Le nombre d'objets �voluant dans le syst�me
  Nb_objets =0; 
  Nb_indiv=112;
  %% Pourcentage De chaque classe d'individu par ordre croissant de classe d'age
  pop=zeros(2,16);
  pop(1,:)=[0.0,0.06,1.00,12.75,12.25,12.50,12.04,11.42,10.03,6.05,5.43,5.11,4.49,3.44,2.08,1.35]/100;
  pop(2,:)=floor(Nb_indiv*pop(1,:));
  %% mise � jour de Nb_indiv
  Nb_indiv=sum(pop(2,:));
  %% Tableau contenant les vitesses souhait�es de chaque classe d'age
  Taille=16;
  vitess_m=zeros(2,Taille);
  vitess_m(1,:)=[0.88,1.15,1.20,1.36,1.42,1.42,1.42,1.42,1.39,1.39,1.30,1.30,1.26,1.26,1.01,1.01];
  vitess_m(2,:)=[0.1061,0.04,0.0489,0.0363,0.0357,0.0357,0.0511,0.0511,0.0653,0.0653,0.0233,0.0233,0.0234,0.0234,0.0039,0.0039];
  %% Tableau contenant les vitesses souhait�es de chaque classe d'age
  Taille=16;
  dist_soc=zeros(2,Taille);
  dist_soc(1,:)=[1.99,1.99,2.04,2.04,2.16,2.16,2.19,2.19,2.15,2.15,2.11,2.11,2.12,2.12,2.24,2.24];
  dist_soc(2,:)=[0.0569,0.0569,0.0755,0.0755,0.0727,0.0727,0.0814,0.0814,0.0767,0.0767,0.0669,0.0669,0.0736,0.0736,0.0477,0.0477];
  %% Tableau contenant les rayons de chaque classe d'age
  Taille=16;
  Masse_m=zeros(2,Taille);
  Masse_m(1,:)=[13.10,20.91,34.525,50.532,60.95,66.05,73.25,73.25,73.55,73.55,73.10,73.10,72.1,71.99,67.05,70.39];
  Masse_m(2,:)=[4.05,2.935,6.553,7.196,10.45,13.25,14.75,14.75,16.25,16.25,23.00,23.00,13.63,13.63,15.50,16.71];
  %Masse_m(2,:)=[1.22,0.488,1.16,5.192,5.192,5.152,5.152,4.728,4.728,3.782,3.782,3.70,3.70,4.492,4.492,4.314];
  %Masse_m(2,:)=[1.22,0.488,5.82,25.95,25.95,25.76,25.76,23.64,23.64,18.91,18.91,18.5,18.5,22.46,22.46,21.57];
  %% Tableau contenant les rayons
  Rayon_m=sqrt(Masse_m/(500*pi));
  %% Tableau contenant l'amplitude de la force de repulsion pour differentes classes d'age
  Taille=16;
  A_m=zeros(2,Taille);
  %A_m(1,:)=[10,10,75,110,122,127,142,142,180,225,247,247,290,305,305,305];
  A_m(1,:)=700*ones(1,Taille);
  A_m(2,:)=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0];
  %% Tableau contenant la portee de la force de repulsion pour chaque classe
  Taille=16;
  B_m=zeros(2,Taille);
  B_m(1,:)=[0.8,0.8,0.8,0.8,0.8,0.8,0.8,0.8,0.8,0.8,0.8,0.8,0.8,0.8,0.8,0.8];
  B_m(2,:)=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0];
  %% Tableau contenant le tau de relaxation de chauqe classe
  Taille=16;
  Tau_m=zeros(2,Taille);
  Tau_m(1,:)=[0.5,0.5,0.5,0.54,0.54,0.54,0.54,0.54,0.71,0.71,0.71,0.71,0.71,0.71,0.71,0.71];
  Tau_m(2,:)=[0.05,0.05,0.05,0.05,0.05,0.05,0.05,0.05,0.1,0.1,0.1,0.1,0.1,0.1,0.1,0.1];
  %% duree de visite du centre pour chaque classe
  Taille=16;
  T_m=zeros(2,Taille);
  T_m(1,:)=[300,300,300,300,300,300,300,300,300,300,300,300,300,300,300,300];
%% Le nombre d'obstacles & Sorties
  Nb_obstacles_Rectangle = 0;
  Nb_Sortie = 0;
  Nb_obstacles_Cercle = 0;
%% la dur�e de simulation, le pas de temps espace et le nombre d'it�rations
  T = 600; 
  h = (1e-2)/2; %pas du temps
  N_iter = T/h;
  n = 0;
%% le domaine dans lequel va �voluer le syst�me
  Xmin = -1;
  Xmax = 51;
  Ymin = -1;
  Ymax = 51;
  %% pour la marche al�atoire
  Direcs=[1,0;-1,0;0,1;0,-1;1,1;-1,-1;1,-1;-1,1];
%% Pour Fast Marching
  ph=1;
% Lorsque la sortie est en bordure d'espace, augmenter la taille de l'espace d'�volution pour ne pas avoir de probl�me  
    np=5;
    Xminn=Xmin-np*ph;
    Xmaxx=Xmax+np*ph;
    Yminn=Ymin-np*ph;
    Ymaxx=Ymax+np*ph;
%% Les parametres de l'equation de contact 
  K_N_obj=1000;
  K_T_obj=0;
  K_T_obs=0;
  K_N_obs=1e5;
  K_T=0;
  K_N=0;
%% Les parametres intervenant dans les forces
%% la focre repulsie pieton-pieton
   A_obj=[];
   B_obj=[]; 
   alpha=0.9;
   d_obj=[];
   R_obj=10;
%% la focre repulsie pieton-obstacle
   A_obs=1000;
   B_obs=0.8;
   d_obs=1.8;
   R_obs=10;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
%% Creation de la geometrie
eps=1;
%gauche
Ajouter_Obstacle_Rectangle(-eps,-eps,eps,50+2*eps);
%droite
Ajouter_Obstacle_Rectangle(50,-eps,eps,50+2*eps);
%Haut
Ajouter_Obstacle_Rectangle(0,50,50,eps);
%bas
Ajouter_Obstacle_Rectangle(0,-eps,50,eps);
% % % %%
% % % %gauche
% % % Ajouter_Obstacle_Rectangle(-eps,-eps,eps,7+2*eps);%(-eps,-eps, eps, xmax+2eps)
% % % %droite
% % % Ajouter_Obstacle_Rectangle(7,-eps,eps,7+2*eps);%(xmax,-eps,eps,ymax+2eps)
% % % %Haut
% % % Ajouter_Obstacle_Rectangle(0,7,7,eps);%(0,ymax,xmax,eps)
% % % %bas
% % % Ajouter_Obstacle_Rectangle(0,-eps,7,eps);%(0,-eps,xmax,eps)
%%
%% Cr�ation des objets
Masse=[];
q=[];
Rayon=[];
Ray=[];
Allure=[];
Tau=[];
% Duree de visite du centre commercial
T_d=[];
 for i=1:size(pop,2)
     Ajouter_Plusieurs_Objets(pop(2,i),Xmin+2,Xmax-2,Ymin+2,Ymax-2,i);
 end
 %% Force Motrice
Allure=[Allure';Allure'];
Allure=Allure(:);
V_ant=zeros(2*Nb_objets,1);
%% Matrices pour la transmission du virus
% initialisation des matrice contenant les indices des individus
% contamines,infectieux et le temps ou ces phenomenes ont lieu
% ainsi que les matrices donnant le nombre de personnes susceptibles,
% infectées et infectieuses à chaque instant
p_infecte = [];
p_infectious=[];
p_s=[]
nbr_s=[];
nbr_infecte=[];
nbr_indirecte=[];
nbr_directe=[];
%% Parmetres des equations de Concentration du virus
mu=9.26e-5;        % duree de vie du virus dans l'air
d0=1;             % distance maximale a� laquelle une surface est contaminee
alpha=59.5e-2;    %Taux de particule qui restent en suspension 
D=0.01;            % Coefficient de diffusion des particules
w=637000;           % Taux de virus produit apres une toux 
gamma=1.9e-6;       % coefficient de degradation du virus a l'interieur d'un individu
ro=1.3e-4;          % taux de virus inocule par un individu qui depend de l'air et de la concentration du virus
hx=0.1;              % le pas de discretisation uniforme
%% discretisation de l'espace
x=Xmin:hx:Xmax;
y=Ymin:hx:Ymax;
Nx=length(x);
Ny=length(y);
%% creation du maillage
[X,Y]=meshgrid(x,y);
% Initialisation des matrices de taux de production et de concentration
Ca=zeros(size(X));
Cacc=zeros(1,Nb_objets); %Matrice contenant les concentrations dans chaque individu
n_infecte=0;           % nombre de personnes infectees
n_directe=0;                 % le nombre de transmission directe
n_indirecte=0;         % le nombre de transmission indirecte
% Initialisation de la matrice contenant les indices des individus
% infectieux
% ccc=setdiff([1:Nb_objets],masks);
% ddd=randperm(length(ccc),2);
% p_infectious=ccc(ddd)';
% ro(p_infectious)=[];
p_infectious=randperm(Nb_objets,3)'
% p_infectious=(randperm(Nb_objets,3))';
%%% Initialisation de la matrice contenant les indices des susceptibles
p_s=1:1:Nb_objets;
p_s=p_s';
p_s=setdiff(p_s,p_infectious);
t=0;
 Affichage_Resultats0