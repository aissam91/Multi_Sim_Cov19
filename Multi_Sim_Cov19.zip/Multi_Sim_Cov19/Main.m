%% Multi_Sim_Cov19
% Code Multi-scale modeling of the risk of infection by covid19 (Multi_Sim_Cov19):
%Coupling of a crowd dynamics model (social forces model) and a spatio-temporal model
% of virus transmission dynamics to estimate the risk of infection in different places of activity.
% Authors : Dramanne Sam Idris Kant�, Aissam jebrane, Anass Bouchnita and Abdelilah Hakim
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Declaration and Initialization of variables
% Declaration of global variables: speed and position, contact, geometry parameters.
clear all
close;
clc;
format long;
Variables_Globales;  
Initialisation;
%% Open Animation
date1=clock;
Animation = VideoWriter('sim.avi');
open(Animation) 
%% main loop
while(n<N_iter)
   n=n+1 
   %% parameter used to implement transmission
   t=t+h;
   Wd=zeros(size(X)); 
    v_test=0;
%% Calcul of the desired speed & motrice force 
   f_ac=zeros(2*Nb_objets,1);
   f_ac=(Allure.*D_S-V_ant)./Tau;
%% compute of the rectangular obstacle repelling force.
   f_obs=zeros(2*Nb_objets,1);
   for j=1:Nb_obstacles_Rectangle 
      A=Dis_objet_rectangle(j);
      f_obs(2*[1:Nb_objets]-1,1)=f_obs(2*[1:Nb_objets]-1,1)+(A_obs*exp((d_obs-A(:,1))./B_obs).*A(:,2));
      f_obs(2*[1:Nb_objets],1)=f_obs(2*[1:Nb_objets],1)+(A_obs*exp((d_obs-A(:,1))./B_obs).*A(:,3));
   end

%% compute of the individuals repelling force.
   normm=squareform(pdist(reshape(q,2,Nb_objets)'))+diag(2*ones(Nb_objets,1));
   Dis=squareform(pdist(reshape(q,2,Nb_objets)'))-(meshgrid(Rayon)'+meshgrid(Rayon));
   ex=(meshgrid(q(2*[1:Nb_objets]-1))'-meshgrid(q(2*[1:Nb_objets]-1)))./normm;
   ey=(meshgrid(q(2*[1:Nb_objets]))'-meshgrid(q(2*[1:Nb_objets])))./normm;
   cosphi=(repmat(D_S(2*[1:Nb_objets]-1),1,Nb_objets).*ex+repmat(D_S(2*[1:Nb_objets]),1,Nb_objets).*ey)./sqrt(repmat(D_S(2*[1:Nb_objets]-1),1,Nb_objets).^2+repmat(D_S(2*[1:Nb_objets]),1,Nb_objets).^2);
   idn=find(Dis>R_obj);
   coef=A_obj.*exp((d_obj-Dis)./B_obj).*(alpha+(1-alpha)*(1+cosphi)./2);
   coef=coef-diag(diag(coef));
   coef(idn)=0;
   ex(idn)=0;
   ey(idn)=0;
   f_obj=zeros(2*Nb_objets,1);
   f_obj(2*[1:Nb_objets]-1,1)=sum(coef.*ex,2)';
   f_obj(2*[1:Nb_objets],1)=sum(coef.*ey,2)';
%%  velocity update 
   f=f_ac+1./Masse.*(f_obj+f_obs);
   V_new=V_ant+h*f;
%%  velocity update
      q = q +(V_new+V_ant)*h/2;
       V_ant=V_new;
       Dis=squareform(pdist(reshape(q,2,Nb_objets)'))-(meshgrid(Rayon)'+meshgrid(Rayon));
      %%  transmission process
    if isempty(p_infectious)==0
        for drr=1:length(p_infectious)
    i=p_infectious(drr);
        ip=round((q(2*i)-Ymin)/hx)+1;
        jp=round((q(2*i-1)-Xmin)/hx)+1;
        d=sqrt((X-X(ip,jp)).^2+(Y-Y(ip,jp)).^2);
        MI=zeros(size(d));
          MI=0.25*(1+cos(pi*d/d0));        
        dd=find(d>d0);
        MI(dd)=0;
        Wd=Wd+MI;   
        end
    end
      
   %% Virus concentration update (Matrix C).
   Ca=Ca+h*(D*del2(Ca,hx)+alpha*w*Wd-mu*Ca);
   %% C_acc update
   ip=round((q(2*p_s)-Ymin)/hx)+1;
   jp=round((q(2*p_s-1)-Xmin)/hx)+1;
   Cacc(1,p_s)=Cacc(1,p_s)+h*(ro.*diag(Ca(ip,jp))'-gamma*Cacc(1,p_s));
   Matrix2(1,n+1)=sum(Cacc)/length(p_s);
       
       
            
            
%% Viewing Results
            if ((n==1)||(mod(n*h,100*h)==0)) % modifier "A2" dans "mod(A1,A2)" pour afficher les r�sultats toutes les "A2" secondes
                Affichage_Resultats0;
               frame = getframe(1);
               im = frame2im(frame);
               writeVideo(Animation,im);
               pause(h);
 
           end

end  % end of the main loop
%% close Animation
close(Animation)
Affichage_Resultats0;
%% Display of the calculation time of the simulation
date2=clock;
Resultat=date2-date1;
fprintf(['\nTemps de simulation : ', num2str(Resultat)]);
fprintf(' \n****** Fin de la simulation ****** \n');
%%******************************************%%

%% Accumulated concentration by age group
for i=1:16
    compt=find(Code==i);
    if isempty(compt)==1
        Matrix1(i)=0;
    else
    mini=min(compt);
    maxi=max(compt);
    Matrix1(i)=sum(Cacc(mini:maxi))/length([mini:maxi]);
    end
end
%% Load parameters 
load('Cacc_shop.mat')
load('Matrix1_shop.mat')
load('Matrix2_shop.mat')
Cacc_shop=[Cacc_shop;Cacc]
Matrix1_shop=[Matrix1_shop;Matrix1];
Matrix2_shop=[Matrix2_shop;Matrix2];
save('Cacc_shop.mat','Cacc_shop');
save('Matrix1_shop.mat','Matrix1_shop');
save('Matrix2_shop.mat','Matrix2_shop');